library(dplyr)
library(ggplot2)
library(psych)
library(correlation)
library(gridExtra)
setwd("S:/Lab-Shared/Experiments/Crossmodal inattention/papers/paper a - valence/exp 2 control data")
low=read.csv("low_level_features_w2v_heb.csv") %>% na.omit()
low[,2:53]=scale(low[,2:53])
high=read.csv("high_level_features_w2v_heb.csv") %>% na.omit()
high[,2:53]=scale(high[,2:53])

# Enhanced function with both uncorrected and FDR-corrected p-value distributions
plot_corr <- function(df1, var1, df2, cols, title=NULL) {
  # Run correlation with and without correction
  corr_res_fdr <- correlation(df1[[var1]], df2[,cols], p_adjust="fdr")
  corr_res_uncorr <- correlation(df1[[var1]], df2[,cols], p_adjust="none") # Uncorrected
  
  # Count significant results (both corrected and uncorrected)
  sig_count_fdr <- sum(corr_res_fdr$p < 0.1)
  sig_count_uncorr <- sum(corr_res_uncorr$p < 0.05)
  
  # Create r-value density plot with mean/CI
  p1 <- ggplot(data.frame(corr_res_fdr), aes(x=r)) +
    stat_summary(aes(y=-0.03), fun.data=mean_cl_normal, geom="pointrange", 
                 orientation="y", color="black", linewidth=1) +
    geom_histogram(fill="darkblue", alpha=0.4) +
    ggtitle(paste0(title, " (r values)")) +
    labs(subtitle = paste0("Sig FDR: ", sig_count_fdr, ", Sig Uncorr: ", sig_count_uncorr),y="count") +
    theme_classic()
  
  # Create uncorrected p-value distribution plot
  p2 <- ggplot(data.frame(corr_res_uncorr), aes(x=p)) +
    geom_histogram(fill="darkred", alpha=0.6, bins=20) +
    geom_vline(xintercept=0.05, linetype="dashed") +
    ggtitle(paste0(title, " (uncorrected p values)")) +
    theme_classic()
  
  # Create FDR-corrected p-value distribution plot
  p3 <- ggplot(data.frame(corr_res_fdr), aes(x=p)) +
    geom_histogram(fill="darkgreen", alpha=0.6, bins=20) +
    geom_vline(xintercept=0.05, linetype="dashed") +
    ggtitle(paste0(title, " (FDR-corrected p values)")) +
    theme_classic()
  
  # Return both results and plots
  return(list(corr_fdr=corr_res_fdr, corr_uncorr=corr_res_uncorr, 
              r_plot=p1, p_uncorr_plot=p2, p_fdr_plot=p3, 
              sig_fdr=sig_count_fdr, sig_uncorr=sig_count_uncorr))
}

# Enhanced model function with significance test and both p-value types
extract_model_stats <- function(dv, data, cols, model_name="Model") {
  # Create model
  m <- lm(scale(data[[dv]]) ~ as.matrix(data[,cols]))
  
  # Get model summary
  model_summary <- summary(m)
  
  # Get overall model F-test results
  f_stat <- model_summary$fstatistic
  model_p <- pf(f_stat[1], f_stat[2], f_stat[3], lower.tail=FALSE)
  
  # Get p-values and apply FDR correction
  p_vals <- model_summary$coefficients[,4]
  p_adj <- p.adjust(p_vals, method="fdr")
  
  # Create results table with both p-values
  results <- data.frame(
    predictor = c("Intercept", colnames(data[,cols])),
    estimate = model_summary$coefficients[,1],
    std_error = model_summary$coefficients[,2],
    t_value = model_summary$coefficients[,3],
    p_uncorr = p_vals,
    p_fdr = p_adj,
    model = model_name  # Add model name for plotting
  )
  
  # Get adjusted R-squared
  adj_r2 <- model_summary$adj.r.squared
  
  # Print results
  cat("\n", model_name, "\n")
  cat("----------------------------------\n")
  cat("Model Significance: F(", f_stat[2], ",", f_stat[3], ") = ", 
      round(f_stat[1], 2), ", p = ", format.pval(model_p, digits=3), "\n")
  cat("Adjusted R²:", round(adj_r2, 4), "\n\n")
  
  # Find and print significant predictors (both uncorrected and FDR)
  sig_uncorr <- results[results$p_uncorr < 0.05,]
  sig_fdr <- results[results$p_fdr < 0.05,]
  
  cat("Significant predictors\n (uncorrected p < 0.05):", nrow(sig_uncorr), "\n")
  if(nrow(sig_uncorr) > 0 && nrow(sig_uncorr) <= 10) {
    print(sig_uncorr[order(sig_uncorr$p_uncorr), c("predictor", "p_uncorr")])
  } else if(nrow(sig_uncorr) > 10) {
    print(head(sig_uncorr[order(sig_uncorr$p_uncorr), c("predictor", "p_uncorr")], 10))
    cat("(showing top 10 only)\n")
  }
  
  cat("\nSignificant predictors (FDR p < 0.05):", nrow(sig_fdr), "\n")
  if(nrow(sig_fdr) > 0) {
    print(sig_fdr[order(sig_fdr$p_fdr), c("predictor", "p_fdr")])
  }
  
  # Return results
  return(list(
    results = results, 
    adj_r_squared = adj_r2,
    model_p = model_p,
    f_stat = f_stat,
    sig_predictors = sig_fdr
  ))
}

# Run correlation analyses
res1 <- plot_corr(low, "valence", low, 4:53, "Low-level & Valence\n")
res2 <- plot_corr(high, "valence", high, 4:53, "High-level & Valence\n")
res3 <- plot_corr(low, "intelligibility", low, 4:53, "Low-level & Intelligibility\n")
res4 <- plot_corr(high, "intelligibility", high, 4:53, "High-level & Intelligibility\n")

# Display correlation plots
# R-value plots
grid.arrange(res1$r_plot, res2$r_plot, res3$r_plot, res4$r_plot,
             res1$p_uncorr_plot, res2$p_uncorr_plot, res3$p_uncorr_plot, res4$p_uncorr_plot, nrow=2)
# FDR-corrected P-value plots
grid.arrange(res1$p_fdr_plot, res2$p_fdr_plot, res3$p_fdr_plot, res4$p_fdr_plot, ncol=2)



# Enhanced model function with significance test and both p-value types
extract_model_stats <- function(dv, data, cols, model_name="Model") {
  # Create model
  m <- lm(scale(data[[dv]]) ~ as.matrix(data[,cols]))
  
  # Get model summary
  model_summary <- summary(m)
  
  # Get overall model F-test results
  f_stat <- model_summary$fstatistic
  model_p <- pf(f_stat[1], f_stat[2], f_stat[3], lower.tail=FALSE)
  
  # Get p-values and apply FDR correction
  p_vals <- model_summary$coefficients[,4]
  p_adj <- p.adjust(p_vals, method="fdr")
  
  # Create results table with both p-values
  results <- data.frame(
    predictor = c("Intercept", colnames(data[,cols])),
    estimate = model_summary$coefficients[,1],
    std_error = model_summary$coefficients[,2],
    t_value = model_summary$coefficients[,3],
    p_uncorr = p_vals,
    p_fdr = p_adj,
    model = model_name  # Add model name for plotting
  )
  
  # Get adjusted R-squared
  adj_r2 <- model_summary$adj.r.squared
  
  # Count significant predictors
  sig_uncorr_count <- sum(p_vals[-1] < 0.05)  # Exclude intercept
  sig_fdr_count <- sum(p_adj[-1] < 0.05)      # Exclude intercept
  
  # Print results
  cat("\n", model_name, "\n")
  cat("----------------------------------\n")
  cat("Model Significance: F(", f_stat[2], ",", f_stat[3], ") = ", 
      round(f_stat[1], 2), ", p = ", format.pval(model_p, digits=3), "\n")
  cat("Adjusted R²:", round(adj_r2, 4), "\n")
  cat("Significant predictors (uncorrected): ", sig_uncorr_count, "\n")
  cat("Significant predictors (FDR): ", sig_fdr_count, "\n\n")
  
  # Find and print significant predictors (both uncorrected and FDR)
  sig_uncorr <- results[results$p_uncorr < 0.05 & results$predictor != "Intercept",]
  sig_fdr <- results[results$p_fdr < 0.05 & results$predictor != "Intercept",]
  
  cat("Significant predictors (uncorrected p < 0.05):", nrow(sig_uncorr), "\n")
  if(nrow(sig_uncorr) > 0 && nrow(sig_uncorr) <= 10) {
    print(sig_uncorr[order(sig_uncorr$p_uncorr), c("predictor", "p_uncorr")])
  } else if(nrow(sig_uncorr) > 10) {
    print(head(sig_uncorr[order(sig_uncorr$p_uncorr), c("predictor", "p_uncorr")], 10))
    cat("(showing top 10 only)\n")
  }
  
  cat("\nSignificant predictors (FDR p < 0.05):", nrow(sig_fdr), "\n")
  if(nrow(sig_fdr) > 0) {
    print(sig_fdr[order(sig_fdr$p_fdr), c("predictor", "p_fdr")])
  }
  
  # Return results
  return(list(
    results = results, 
    adj_r_squared = adj_r2,
    model_p = model_p,
    f_stat = f_stat,
    sig_predictors_fdr = sig_fdr_count,
    sig_predictors_uncorr = sig_uncorr_count
  ))
}

# Run regression analyses for top 20 components
low_val_25 <- extract_model_stats("valence", low, 4:23, "Low-level & Valence (top 20)")
high_val_25 <- extract_model_stats("valence", high, 4:23, "High-level & Valence (top 20)")
low_intel_25 <- extract_model_stats("intelligibility", low, 4:23, "Low-level & Intelligibility (top 20)")
high_intel_25 <- extract_model_stats("intelligibility", high, 4:23, "High-level & Intelligibility (top 20)")

# Create summary plot of R-squared values with sig predictor counts
r_squared_df_25 <- data.frame(
  Model = c("Low-level &Valence", "High-level & Valence", "Low-level & Intelligibility", "High-level & Intelligibility"),
  Adjusted_R2 = c(low_val_25$adj_r_squared, high_val_25$adj_r_squared, 
                  low_intel_25$adj_r_squared, high_intel_25$adj_r_squared),
  Significance = c(low_val_25$model_p, high_val_25$model_p, 
                   low_intel_25$model_p, high_intel_25$model_p) < 0.05,
  Sig_Predictors = c(low_val_25$sig_predictors_fdr, high_val_25$sig_predictors_fdr,
                     low_intel_25$sig_predictors_fdr, high_intel_25$sig_predictors_fdr)
)

# Plot R-squared comparison for top 25
r2_plot_25 <- ggplot(r_squared_df_25, aes(x=Model, y=Adjusted_R2, fill=Significance)) +
  geom_bar(stat="identity") +
  geom_text(aes(label=paste0(round(Adjusted_R2, 3), "\n(sig: ", Sig_Predictors, ")")), 
            vjust=-0.5, size=3.5) +
  scale_fill_manual(values=c("darkgrey", "darkblue")) +
  labs(title="Top 20 components: Adjusted R²", y="Adjusted R²") +
  theme_classic() +
  theme(axis.text.x = element_text(angle=45, hjust=1),legend.position = "none")+
  ylim(-0.1,0.34)

# Run regression analyses for top 10 components
low_val_10 <- extract_model_stats("valence", low, 4:13, "Low-level & Valence (top 10)")
high_val_10 <- extract_model_stats("valence", high, 4:13, "High-level &  Valence (top 10)")
low_intel_10 <- extract_model_stats("intelligibility", low, 4:13, "Low-level &  Intelligibility (top 10)")
high_intel_10 <- extract_model_stats("intelligibility", high, 4:13, "High-level &  Intelligibility (top 10)")

# Create summary plot of R-squared values with sig predictor counts
r_squared_df_10 <- data.frame(
  Model = c("Low-level &  Valence", "High-level &  Valence", "Low-level &  Intelligibility", "High-level &  Intelligibility"),
  Adjusted_R2 = c(low_val_10$adj_r_squared, high_val_10$adj_r_squared, 
                  low_intel_10$adj_r_squared, high_intel_10$adj_r_squared),
  Significance = c(low_val_10$model_p, high_val_10$model_p, 
                   low_intel_10$model_p, high_intel_10$model_p) < 0.05,
  Sig_Predictors = c(low_val_10$sig_predictors_fdr, high_val_10$sig_predictors_fdr,
                     low_intel_10$sig_predictors_fdr, high_intel_10$sig_predictors_fdr)
)

# Plot R-squared comparison for top 10
r2_plot_10 <- ggplot(r_squared_df_10, aes(x=Model, y=Adjusted_R2, fill=Significance)) +
  geom_bar(stat="identity") +
  geom_text(aes(label=paste0(round(Adjusted_R2, 3), "\n(sig: ", Sig_Predictors, ")")), 
            vjust=-0.5, size=3.5) +
  scale_fill_manual(values=c("darkgrey", "darkblue")) +
  labs(title="Top 10 components: Adjusted R²", y="Adjusted R²") +
  theme_classic() +
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  ylim(-0.1,0.34)

# Display both plots
library(gridExtra)
grid.arrange(r2_plot_25, r2_plot_10, ncol=2)

plot_coefficients <- function(model_results, title, sig_level = 0.05) {
  # Get coefficients excluding intercept and keep only top 10 features
  coefs <- model_results$results[2:17, ]  # Intercept + first 10 features
  
  # Create significance indicator
  coefs$significant <- coefs$p_fdr < sig_level
  
  # Order by feature number
  coefs$predictor_num <- 1:nrow(coefs)
  coefs$predictor <- factor(coefs$predictor, levels = coefs$predictor)
  
  # Create the plot with error bars
  p <- ggplot(coefs %>%na.omit(), aes(x = predictor, y = estimate, fill = significant)) +
    geom_bar(stat = "identity") +
    # Add error bars using standard error
    geom_errorbar(aes(ymin = estimate - std_error, 
                      ymax = estimate + std_error),
                  width = 0.2) +
    scale_fill_manual(values = c("darkgrey", "darkblue")) +
    labs(title = title, y = "Coefficient", x = "Feature") +ylim(-0.5,0.5)+
    geom_hline(yintercept=0)+
    theme_classic() +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "none"
    )
  
  return(p)
}


# Create coefficient plots for each model (top 10 features)
p1 <- plot_coefficients(low_val_10, "Low & Valence - Top 10 Features")
p2 <- plot_coefficients(high_val_10, "High & Valence - Top 10 Features")
p3 <- plot_coefficients(low_intel_10, "Low & Intelligibility - Top 10 Features")
p4 <- plot_coefficients(high_intel_10, "High & Intelligibility - Top 10 Features")

# Display all coefficient plots
grid.arrange(p1, p2, p3, p4, ncol = 2)

# If you want to combine with the R-squared plots
all_plots <- grid.arrange(
  r2_plot_10,
  arrangeGrob(p1, p2, p3, p4, ncol = 2),
  nrow = 2,
  heights = c(1, 2)
)